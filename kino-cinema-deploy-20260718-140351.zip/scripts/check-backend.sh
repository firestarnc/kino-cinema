#!/usr/bin/env bash

set -euo pipefail

PORT="${PORT:-3000}"
HOST="${HOST:-127.0.0.1}"
URL="http://${HOST}:${PORT}/"

if curl -fsS "${URL}" >/dev/null; then
  echo "Backend OK at ${URL}"
  exit 0
fi

echo "Backend DOWN at ${URL}"
exit 1
