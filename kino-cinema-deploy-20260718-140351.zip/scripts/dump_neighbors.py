#!/usr/bin/env python3
import json
from pathlib import Path
from collections import deque, defaultdict

Gpath = Path('graphify-out/graph.json')
Apath = Path('graphify-out/.graphify_analysis.json')
OUT = Path('graphify-out/neighbor_sets.json')
if not Gpath.exists() or not Apath.exists():
    print('Required graph files missing. Run local_graphify.py first.')
    raise SystemExit(1)
G = json.loads(Gpath.read_text(encoding='utf-8'))
A = json.loads(Apath.read_text(encoding='utf-8'))
communities = A.get('communities', {})

# Identify source and target communities
src_key = '550'
tgt_key = '0'
if src_key not in communities:
    for k,v in communities.items():
        for n in v:
            if 'screening/[filmId]' in n or 'FilmDetailClient' in n:
                src_key = k
                break
        if src_key == k:
            break

src_nodes = communities.get(src_key, [])
tgt_nodes = communities.get(tgt_key, [])

nodes = {n['id'] for n in G.get('nodes', [])}
adj = {n:set() for n in nodes}
for e in G.get('edges', []):
    s = e.get('source'); t = e.get('target')
    if s in adj and t in adj:
        adj[s].add(t); adj[t].add(s)

# BFS up to depth K
def bfs_up_to_k(start, k=2):
    q = deque([(start,0)])
    seen = {start:0}
    while q:
        u,d = q.popleft()
        if d==k: continue
        for v in adj.get(u,[]):
            if v not in seen:
                seen[v]=d+1
                q.append((v,d+1))
    seen.pop(start, None)
    return seen

result = {
    'src_key': src_key,
    'tgt_key': tgt_key,
    'src_nodes': src_nodes,
    'tgt_nodes': tgt_nodes,
    'src_neighbors': {},
    'tgt_neighbors': {},
    'connectors': []
}

combined_src = defaultdict(lambda: set())
for s in src_nodes:
    if s not in nodes:
        continue
    neigh = bfs_up_to_k(s, k=2)
    for n,d in neigh.items():
        combined_src[d].add(n)

combined_tgt = defaultdict(lambda: set())
for t in tgt_nodes:
    if t not in nodes:
        continue
    neigh = bfs_up_to_k(t, k=2)
    for n,d in neigh.items():
        combined_tgt[d].add(n)

# convert sets to sorted lists
result['src_neighbors'] = {str(d): sorted(list(v)) for d,v in combined_src.items()}
result['tgt_neighbors'] = {str(d): sorted(list(v)) for d,v in combined_tgt.items()}

src_all = set().union(*combined_src.values()) if combined_src else set()
tgt_all = set().union(*combined_tgt.values()) if combined_tgt else set()
connectors = sorted(list(src_all & tgt_all))
result['connectors'] = connectors

OUT.write_text(json.dumps(result, indent=2, ensure_ascii=False), encoding='utf-8')
print('Wrote', OUT)
