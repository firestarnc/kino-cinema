#!/usr/bin/env python3
"""Lightweight local graph builder: scans repo files, extracts local imports,
builds a file-level graph, computes communities (connected components),
and writes graphify-like outputs to graphify-out/.
"""
import os
import re
import json
from pathlib import Path
from collections import defaultdict, Counter, deque

ROOT = Path('.').resolve()
OUT = Path('graphify-out')
OUT.mkdir(exist_ok=True)

EXTS = {'.ts', '.tsx', '.js', '.jsx', '.py', '.md', '.mdx', '.json'}
IMPORT_RE = re.compile(r"from\s+['\"]([^'\"]+)['\"]|import\s+['\"]([^'\"]+)['\"]")


def discover_files():
    files = []
    for p in ROOT.rglob('*'):
        if p.is_file() and p.suffix in EXTS and 'node_modules' not in p.parts and p.match('**/*.d.ts') is False:
            files.append(p.relative_to(ROOT).as_posix())
    return sorted(files)


def extract_imports(path):
    imports = []
    try:
        text = Path(path).read_text(encoding='utf-8', errors='ignore')
    except Exception:
        return imports
    for m in IMPORT_RE.finditer(text):
        target = m.group(1) or m.group(2)
        if not target:
            continue
        if target.startswith('.'):
            imports.append(target)
    return imports


def resolve_import(from_file, target):
    # Resolve relative import to a file in corpus (approximate)
    base = (ROOT / from_file).parent
    cand = (base / target)
    # try extensions
    if cand.exists() and cand.is_file():
        try:
            return cand.relative_to(ROOT).as_posix()
        except Exception:
            return str(cand)
    for ext in ('', '.ts', '.tsx', '.js', '.jsx', '.py', '.json', '.md'):
        p = Path(str(cand) + ext)
        if p.exists():
            try:
                return p.relative_to(ROOT).as_posix()
            except Exception:
                return str(p)
    # index file
    for ext in ('.ts', '.tsx', '.js', '.jsx', '.py', '.json'):
        p = cand / ('index' + ext)
        if p.exists():
            try:
                return p.relative_to(ROOT).as_posix()
            except Exception:
                return str(p)
    return None


def build_graph(files):
    nodes = {f: {'id': f, 'label': Path(f).name} for f in files}
    edges = []
    adj = defaultdict(set)
    for f in files:
        imps = extract_imports(f)
        for imp in imps:
            resolved = resolve_import(f, imp)
            if resolved and resolved in nodes:
                edges.append({'source': f, 'target': resolved})
                adj[f].add(resolved)
                adj[resolved].add(f)
    return nodes, edges, adj


def connected_components(adj, nodes):
    seen = set()
    comps = []
    for n in nodes:
        if n in seen:
            continue
        q = deque([n])
        comp = []
        seen.add(n)
        while q:
            u = q.popleft()
            comp.append(u)
            for v in adj.get(u, []):
                if v not in seen:
                    seen.add(v)
                    q.append(v)
        comps.append(sorted(comp))
    return comps


def analyze(nodes, edges, adj):
    deg = {n: len(adj.get(n, [])) for n in nodes}
    top = sorted(deg.items(), key=lambda x: -x[1])
    god_nodes = [{'id': n, 'degree': d} for n, d in top[:10]]
    comps = connected_components(adj, list(nodes))
    comp_map = {}
    for i, c in enumerate(comps):
        for n in c:
            comp_map[n] = i
    surprises = []
    for e in edges:
        s = e['source']; t = e['target']
        if comp_map.get(s) != comp_map.get(t):
            surprises.append({'source': s, 'target': t, 'communities': (comp_map.get(s), comp_map.get(t))})
    questions = []
    if len(comps) >= 2:
        # pick largest two
        comps_sorted = sorted(enumerate(comps), key=lambda x: -len(x[1]))
        a_id, a_nodes = comps_sorted[0]
        b_id, b_nodes = comps_sorted[1]
        questions.append(f"How does code in community {a_id} ({len(a_nodes)} files) interact with community {b_id} ({len(b_nodes)} files)?")
    else:
        questions.append("What are the most central files in the codebase and why?")
    analysis = {
        'communities': {str(i): comps[i] for i in range(len(comps))},
        'cohesion': {str(i): len(comps[i]) for i in range(len(comps))},
        'gods': god_nodes,
        'surprises': surprises,
        'questions': questions,
    }
    return analysis


def write_outputs(nodes, edges, analysis):
    data = {
        'nodes': list(nodes.values()),
        'edges': edges,
    }
    (OUT / 'graph.json').write_text(json.dumps(data, indent=2), encoding='utf-8')
    (OUT / '.graphify_analysis.json').write_text(json.dumps(analysis, indent=2), encoding='utf-8')
    # Write a short GRAPH_REPORT.md with required sections
    parts = []
    parts.append('# GRAPH_REPORT (lightweight local)\n')
    parts.append('\n## God Nodes\n')
    for g in analysis['gods'][:10]:
        parts.append(f"- {g['id']}: degree {g['degree']}\n")
    parts.append('\n## Surprising Connections\n')
    if analysis['surprises']:
        for s in analysis['surprises'][:20]:
            parts.append(f"- {s['source']} → {s['target']} (communities {s['communities'][0]} ↔ {s['communities'][1]})\n")
    else:
        parts.append('- (none detected)\n')
    parts.append('\n## Suggested Questions\n')
    for q in analysis['questions']:
        parts.append(f"- {q}\n")
    (OUT / 'GRAPH_REPORT.md').write_text(''.join(parts), encoding='utf-8')


def main():
    files = discover_files()
    nodes, edges, adj = build_graph(files)
    analysis = analyze(nodes, edges, adj)
    write_outputs(nodes, edges, analysis)
    print('Wrote graph to', OUT.resolve())


if __name__ == '__main__':
    main()
