#!/usr/bin/env python3
import json
from pathlib import Path
from collections import deque, defaultdict

Gpath = Path('graphify-out/graph.json')
Apath = Path('graphify-out/.graphify_analysis.json')
if not Gpath.exists() or not Apath.exists():
    print('Required graph files missing. Run local_graphify.py first.')
    raise SystemExit(1)
G = json.loads(Gpath.read_text(encoding='utf-8'))
A = json.loads(Apath.read_text(encoding='utf-8'))
communities = A.get('communities', {})

src_key = '550'
tgt_key = '0'
if src_key not in communities:
    # fallback: try to find community containing screening files by name
    for k,v in communities.items():
        for n in v:
            if 'screening/[filmId]' in n or 'FilmDetailClient' in n:
                src_key = k
                break
        if src_key == k:
            break

src_nodes = communities.get(src_key, [])
tgt_nodes = set(communities.get(tgt_key, []))

nodes = {n['id'] for n in G.get('nodes', [])}
adj = {n:set() for n in nodes}
for e in G.get('edges', []):
    s = e.get('source'); t = e.get('target')
    if s in adj and t in adj:
        adj[s].add(t); adj[t].add(s)

# BFS up to depth K
def bfs_up_to_k(start, k=2):
    q = deque([(start,0)])
    seen = {start:0}
    while q:
        u,d = q.popleft()
        if d==k: continue
        for v in adj.get(u,[]):
            if v not in seen:
                seen[v]=d+1
                q.append((v,d+1))
    # remove start
    seen.pop(start, None)
    return seen  # node -> distance

# Collect for all src nodes
combined_src = defaultdict(lambda: set())
for s in src_nodes:
    if s not in nodes:
        print('Source node missing from graph:', s)
        continue
    neigh = bfs_up_to_k(s, k=2)
    for n,d in neigh.items():
        combined_src[d].add(n)

# For targets
combined_tgt = defaultdict(lambda: set())
for t in tgt_nodes:
    if t not in nodes:
        print('Target node missing from graph:', t)
        continue
    neigh = bfs_up_to_k(t, k=2)
    for n,d in neigh.items():
        combined_tgt[d].add(n)

print(f"Source community: {src_key} nodes: {len(src_nodes)}")
print(f"Target community: {tgt_key} nodes: {len(tgt_nodes)}\n")

def show_summary(prefix, combined):
    total = sum(len(s) for s in combined.values())
    print(f"{prefix} - unique nodes within 2 hops: {total}")
    for dist in sorted(combined.keys()):
        print(f"  distance {dist}: {len(combined[dist])} nodes")

show_summary('From sources', combined_src)
show_summary('From targets', combined_tgt)

# Potential connectors: intersection of sets at any distances
src_all = set().union(*combined_src.values())
tgt_all = set().union(*combined_tgt.values())
connectors = src_all & tgt_all
print('\nPotential connector nodes (within 2 hops of both):', len(connectors))
if connectors:
    # map to community
    node_to_comm = {}
    for k,v in communities.items():
        for nid in v:
            node_to_comm[nid]=k
    for n in sorted(connectors):
        print('-', n, '(community', node_to_comm.get(n,'?') + ')')

# Print top 20 neighbors from sources with distances
print('\nTop neighbors from sources (sample up to 50):')
count=0
for d in sorted(combined_src.keys()):
    for n in sorted(combined_src[d]):
        comm = next((k for k,v in communities.items() if n in v), '?')
        print(f" dist {d}: {n}  (community {comm})")
        count+=1
        if count>=50: break
    if count>=50: break

print('\nImmediate neighbors of source nodes:')
for s in src_nodes:
    if s not in nodes: continue
    neigh = adj.get(s, set())
    print(f"\n{s} -> {len(neigh)} neighbors:")
    for n in sorted(neigh):
        comm = next((k for k,v in communities.items() if n in v), '?')
        print('  -', n, f'(community {comm})')

print('\nImmediate neighbors of target nodes:')
for t in tgt_nodes:
    if t not in nodes: continue
    neigh = adj.get(t, set())
    print(f"\n{t} -> {len(neigh)} neighbors:")
    for n in sorted(neigh):
        comm = next((k for k,v in communities.items() if n in v), '?')
        print('  -', n, f'(community {comm})')
