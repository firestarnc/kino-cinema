#!/usr/bin/env python3
import json
from pathlib import Path
from collections import deque

GPATH = Path('graphify-out/graph.json')
APATH = Path('graphify-out/.graphify_analysis.json')
if not GPATH.exists():
    print('ERROR: graphify-out/graph.json not found')
    raise SystemExit(1)
if not APATH.exists():
    print('ERROR: graphify-out/.graphify_analysis.json not found')
    raise SystemExit(1)

G = json.loads(GPATH.read_text(encoding='utf-8'))
A = json.loads(APATH.read_text(encoding='utf-8'))
communities = A.get('communities', {})

# try common keys
for key in ('550','542','145'):
    if key in communities:
        target_comm_key = '0'
        src_comm_key = key
        break
# Prefer explicit 550 if present
if '550' in communities:
    src_comm_key = '550'
    target_comm_key = '0'

if src_comm_key not in communities or target_comm_key not in communities:
    print('Available communities:', ', '.join(sorted(communities.keys(), key=int)))
    print('Please specify a valid community key. Exiting.')
    raise SystemExit(1)

src_nodes = communities[src_comm_key]
tgt_nodes = set(communities[target_comm_key])
print(f"Tracing shortest path from community {src_comm_key} ({len(src_nodes)} files) to community {target_comm_key} ({len(tgt_nodes)} files)")

nodes = {n['id'] for n in G.get('nodes', [])}
adj = {n:set() for n in nodes}
for e in G.get('edges', []):
    s = e.get('source')
    t = e.get('target')
    if s in adj and t in adj:
        adj[s].add(t)
        adj[t].add(s)

# BFS from each source node until any target reached; collect shortest path per source
paths = []
for start in src_nodes:
    if start not in nodes:
        continue
    q = deque([start])
    parent = {start: None}
    found = None
    while q and found is None:
        u = q.popleft()
        if u in tgt_nodes:
            found = u
            break
        for v in adj.get(u, []):
            if v not in parent:
                parent[v] = u
                q.append(v)
    if found:
        # reconstruct
        path = []
        cur = found
        while cur is not None:
            path.append(cur)
            cur = parent.get(cur)
        path.reverse()
        paths.append(path)

if not paths:
    print('No path found between the specified communities.')
else:
    # sort by length
    paths.sort(key=len)
    best = paths[0]
    print('Shortest path found (length', len(best)-1, 'edges):')
    # invert community map for quick lookup
    node_to_comm = {}
    for k,v in communities.items():
        for nid in v:
            node_to_comm[nid] = k
    for i,n in enumerate(best, start=1):
        comm = node_to_comm.get(n,'?')
        print(f" {i}. {n}  (community {comm})")
    comms_crossed = sorted({node_to_comm.get(n,'?') for n in best})
    print('Communities crossed in path:', ' -> '.join(comms_crossed))

# If multiple shortest paths exist (same length), optionally list them
if len(paths) > 1:
    minlen = len(paths[0])
    others = [p for p in paths if len(p)==minlen]
    if len(others) > 1:
        print('\nOther equally-short paths:')
        for p in others[1:]:
            print(' - ' + ' -> '.join(p))
