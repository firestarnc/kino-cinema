#!/usr/bin/env python3
"""Simple file watcher that reruns scripts/local_graphify.py on source changes.
Uses mtime polling to avoid external deps.
"""
import time
import subprocess
from pathlib import Path

ROOT = Path('.').resolve()
EXTS = {'.ts', '.tsx', '.js', '.jsx', '.py', '.md', '.mdx', '.json'}
IGNORE_DIRS = {'node_modules', '.git', 'graphify-out', '.next'}


def discover_files():
    files = []
    for p in ROOT.rglob('*'):
        if p.is_file() and p.suffix in EXTS and not any(part in IGNORE_DIRS for part in p.parts):
            files.append(p)
    return files


def snapshot(files):
    return {str(p): p.stat().st_mtime for p in files}


if __name__ == '__main__':
    print('Starting graphify watch (press Ctrl+C to stop)')
    files = discover_files()
    mtimes = snapshot(files)
    try:
        while True:
            time.sleep(1)
            files = discover_files()
            new_mtimes = snapshot(files)
            if new_mtimes != mtimes:
                print('Change detected — rebuilding graph...')
                mtimes = new_mtimes
                try:
                    subprocess.run([str(Path('/Library/Developer/CommandLineTools/usr/bin/python3')), 'scripts/local_graphify.py'], check=True)
                    print('Rebuild complete')
                except subprocess.CalledProcessError as e:
                    print('Rebuild failed:', e)
    except KeyboardInterrupt:
        print('\nWatcher stopped')
